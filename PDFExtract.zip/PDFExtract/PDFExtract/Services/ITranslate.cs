﻿namespace PDFExtract.Services
{
    public interface ITranslate
    {
        public Task<string> TranslateText(string file, string TranslateApiUrl);
    }
}
