﻿using Microsoft.AspNetCore.Mvc;

namespace PDFExtract.Services
{
    public interface IReadFile
    {
        public  Task<string> GetFilePath(List<IFormFile> files);
    }
}
