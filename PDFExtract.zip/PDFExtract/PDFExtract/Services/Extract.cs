﻿using iTextSharp.text.pdf.parser;
using iTextSharp.text.pdf;
using System.Text;

namespace PDFExtract.Services
{
    public class Extract: IExtract
    {

        public string ExtractLogic(string fileLocation)
        {
            StringBuilder sb = new StringBuilder();
            using (PdfReader reader = new PdfReader(fileLocation))
            {
                for (int i = 1; i <= reader.NumberOfPages; i++)
                {
                    ITextExtractionStrategy strategy = new SimpleTextExtractionStrategy();
                    string text = PdfTextExtractor.GetTextFromPage(reader, i, strategy);
                    text = Encoding.UTF8.GetString(ASCIIEncoding.Convert(Encoding.Default, Encoding.UTF8, Encoding.Default.GetBytes(text)));
                    sb.Append(text);
                }
            }
            string res = sb.ToString();
            if (File.Exists(fileLocation))
            {
                File.Delete(fileLocation);
            }
            return res;
        }
    }
}
