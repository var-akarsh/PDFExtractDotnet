﻿using iTextSharp.text.pdf.codec.wmf;
using Newtonsoft.Json;
using Org.BouncyCastle.Asn1.Crmf;
using RestSharp;

namespace PDFExtract.Services
{
    public class Translate : ITranslate
    {
        public async Task<string> TranslateText(string file, string TranslateApiUrl)
        {
            var client = new RestClient(TranslateApiUrl);
            var request = new RestRequest(TranslateApiUrl);
            request.Method = Method.Post;
            request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
            request.AddHeader("X-RapidAPI-Key", "e7a8a01223mshfc632ddc4cc1c2cp14eed2jsn16db0e21bad0");
            request.AddHeader("X-RapidAPI-Host", "google-translate1.p.rapidapi.com");
            request.AddParameter("q", file);
            request.AddParameter("target", "hi");
            request.AddParameter("source", "en");
            RestResponse response = client.Execute(request);
            var res = response.Content;

            TranslateResponse myDeserializedClass = JsonConvert.DeserializeObject<TranslateResponse>(res);
            string result = myDeserializedClass.data.translations[0].translatedText;
            return result;
        }
    }
}
