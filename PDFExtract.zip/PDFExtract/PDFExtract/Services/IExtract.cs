﻿namespace PDFExtract.Services
{
    public interface IExtract
    {
        public string ExtractLogic(string fileLocation);
    }
}
