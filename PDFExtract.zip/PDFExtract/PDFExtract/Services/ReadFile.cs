﻿using Microsoft.AspNetCore.Mvc;

namespace PDFExtract.Services
{
    public class ReadFile : IReadFile
    {
        public async Task<string> GetFilePath(List<IFormFile> files)
        {
            long size = files.Sum(f => f.Length);
            string fileName = files[0].FileName;
            string filePath = @"D:\Core Projects\";
            string fullPath = filePath + fileName;
            foreach (var formFile in files)
            {
                if (formFile.Length > 0)
                {
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        await formFile.CopyToAsync(stream);
                    }
                }
            }
            return  fullPath;
        }
    }
}
