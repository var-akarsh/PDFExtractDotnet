﻿using Microsoft.AspNetCore.Mvc;
using System.Reflection.PortableExecutable;
using System.Text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using PDFExtract.Services;

namespace PDFExtract.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HomeController : Controller
    {
        IReadFile _read;
        IExtract _extract;
        ITranslate _translate;
        string TranslateApiUrl = string.Empty;
        public HomeController(IConfiguration configuration,IReadFile read,IExtract extract,ITranslate translate)
        {
            TranslateApiUrl = configuration.GetValue<string>("TranslateApiUrl");
            _read = read;   
            _extract = extract;
            _translate = translate;
        }
        //[HttpGet]
        //public string Get()
        //{
        //    string file = @"D:\sample.pdf";
        //    return _extract.ExtractLogic(file);

        //}

        [HttpPost]
        public async Task<string> Post(List<IFormFile> files)
        {
            string file =  await _read.GetFilePath(files);

            string content =  _extract.ExtractLogic(file);

           return await  _translate.TranslateText(content, TranslateApiUrl);

        }
    }
}

