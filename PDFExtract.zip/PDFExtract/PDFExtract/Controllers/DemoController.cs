﻿using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Asn1.Pkcs;
using PDFExtract.Services;
using Tesseract;

namespace PDFExtract.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DemoController : Controller
    {

        [HttpGet]
        public string Get()
        {
            string text = string.Empty; 
            using (var engine = new TesseractEngine(@"D:\Core Projects\", "eng", EngineMode.Default))
            using (var img = Pix.LoadFromFile(@"D:\Core Projects\Example.png"))
            using (var page = engine.Process(img))
            {
                text = page.GetText();
                Console.WriteLine(text);

            }
            return text;


        }

    }
}
